package in.co.airline.ticket.airlineticket.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
