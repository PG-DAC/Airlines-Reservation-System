package in.co.airline.ticket.airlineticket.exception;


public class DatabaseException  extends Exception
{

   public DatabaseException(String msg) {
       super(msg);
   }
}

