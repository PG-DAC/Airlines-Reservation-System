package in.co.airline.ticket.airlineticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
